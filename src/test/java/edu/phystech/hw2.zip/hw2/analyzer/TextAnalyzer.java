package edu.phystech.hw2.analyzer;

interface TextAnalyzer {
    Label processText(String text);
}