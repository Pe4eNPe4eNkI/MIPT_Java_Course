package edu.phystech.hw2.analyzer;

public enum Label {
    TOO_LONG, SPAM, NEGATIVE, OK
}
